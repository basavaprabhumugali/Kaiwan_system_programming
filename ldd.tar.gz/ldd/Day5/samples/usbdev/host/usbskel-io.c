/*
 * program to interact with usb-skel
 */

#include <stdio.h>

char wbuf[]={"ABCDEFGH"};

int main()
{
  int fd;
  int nr,nw;
  char buf[100];

  fd = open("/dev/skel0", 0600);
  nw = write(fd, wbuf, 8);
  nr = read(fd,buf,20);
  buf[nr]=0;
  printf("%s\n", buf);
  close(fd);

  return 0;
}

