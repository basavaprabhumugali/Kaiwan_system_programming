/*
 * find and extract PCI configuration and read MAC address for NIC
 * based on pcnet (AMD chip) - pci based driver
 * B R Sahu, 09/05/11
*/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/pci.h>
#include <linux/delay.h>
#include <asm/io.h>

#define DRV_NAME "pcnet"

/* PCI configuration space */

#define VENDOR_ID               0x8086 
#define DEVICE_ID               0x100e

/* Device 82540 Registers */
#define CTRL		0x00		/* Device Control Register */
#define EECD		0x10		/* EEPROM Control and Data Register */
#define EERD		0x14		/* EEPROM Read Register */
#define MDIC		0x20		/* MDI control Register */
#define RAL             0x5400          /* Receive Address Low Register */
#define RAH             0x5404          /* Receive Address High Register */


#define IOADDR		0x00		/* I/O mapped: Address Register */
#define IODATA		0x04		/* I/O mapped: Data Register */

unsigned long IOBase, IOBaseEnd;
unsigned long ulMemoryBase, ulMemoryBaseEnd;
unsigned long ulResFlags;

/* Read MAC address through I/O Registers */
void ReadMACAddrIORegisters(void)
{
  unsigned long status;
  unsigned char dev_addr[8];
  int i;

  printk("\n*** MAC Address thru I/O Mapped Registers ***\n");

  outl(RAL, (long *)(IOBase + IOADDR));
  status = inl((long *)(IOBase + IODATA));
  printk("status = %08x\n", status);
  *(long *)dev_addr = status;
  outl(RAH, (long *)(IOBase + IOADDR));
  status = inl((long *)(IOBase + IODATA));
  printk("status = %08x\n", status);
  *(long *)(dev_addr+4) = status;
  for (i = 0; i < 6; i++)
    printk("%02x ", dev_addr[i]);
 
}

/* Read MAC address thru Memory Mapped I/O Registers */
void ReadMACAddrMemRegisters(void)
{
  unsigned long status;
  unsigned long MemBase;
  unsigned char dev_addr[8];
  int i;

  printk("\n*** MAC Address thru Mem Mapped Registers ***\n");

  MemBase = (unsigned long)ioremap(ulMemoryBase, 0x20000);

  /* read MAC address */
  status = readl((long *)(MemBase + RAL));
  printk("status = %08x\n", status);
  *(long *)dev_addr = status;
  status = readl((long *)(MemBase + RAH));
  printk("status = %08x\n", status);
  *(long *)(dev_addr+4) = status;
  for (i = 0; i < 6; i++)
    printk("%02x ", dev_addr[i]);

  iounmap((void *)MemBase);

}

/* read the configuration space and extract BARs */
int get_card_details(struct pci_dev *pdev)
{
  unsigned char cIntLine;

  printk("\n*** PCI Device Registers ***\n");

  ulMemoryBase = pci_resource_start( (struct pci_dev *)pdev, 0);

  ulMemoryBaseEnd = pci_resource_end( (struct pci_dev *)pdev, 0);

  ulResFlags = pci_resource_flags( (struct pci_dev *)pdev, 0);

  if (ulResFlags & IORESOURCE_MEM)
      printk("BAR0 Memory Mapped Base Address is: %08lx End %08lx\n",
			ulMemoryBase, ulMemoryBaseEnd);

  IOBase = pci_resource_start( (struct pci_dev *)pdev, 2);

  IOBaseEnd = pci_resource_end( (struct pci_dev *)pdev, 2);

  ulResFlags = pci_resource_flags( (struct pci_dev *)pdev, 2);

  if (ulResFlags & IORESOURCE_IO)
      printk("BAR2 I/O Mapped Base Address is: %08lx End %08lx\n",
			IOBase, IOBaseEnd);

  pci_read_config_byte( (struct pci_dev *)pdev,
				PCI_INTERRUPT_LINE, &cIntLine);
  printk("IRQ Used is: %02x \n", cIntLine);

  return 0;
}

int pcnet_probe(struct pci_dev *pdev, const struct pci_device_id *ent)
{
    printk("PCI probe\n");
    pci_enable_device(pdev);

    get_card_details(pdev);

    ReadMACAddrIORegisters();

    ReadMACAddrMemRegisters();

    return 0;
}

void pcnet_remove(struct pci_dev *pdev)
{
    pci_disable_device(pdev);
    printk("PCI remove\n");
}

static struct pci_device_id pcnet_pci_tbl[] = {
	{VENDOR_ID, DEVICE_ID, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
	{0}
};

struct pci_driver pcnet_driver = {
	name: DRV_NAME,
	id_table: pcnet_pci_tbl,
	probe: pcnet_probe,
	remove: pcnet_remove,
};

/* initialization */

int pcnet_init()
{
  printk("Module Initialized\n");

  return pci_register_driver(&pcnet_driver);
}

/* cleanup */

void pcnet_exit()
{
  printk("Module removed\n");
  pci_unregister_driver(&pcnet_driver);
}

module_init(pcnet_init);
module_exit(pcnet_exit);

MODULE_LICENSE("GPL");

