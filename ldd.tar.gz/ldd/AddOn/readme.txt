udev example:

Create a 10-local.rules in the directory /etc/udev/rules.d
containing statement:
   KERNEL=="mydevice" SYMLINK+="my_dev"

On one termial, run
   udevadm monitor

On another terminal, insmod cdev-class driver.

Observe: 
(a) udev monitor messages
(b) ls -l /dev/my*
