/*
 * sysfs interface - uio_dummy.c 
 */

#include <linux/platform_device.h>
#include <linux/module.h>

static long freq;

static long uio_dummy_count;

static ssize_t show_count(struct device *dev, struct device_attribute *attr,
			  char *buf)
{
	return sprintf(buf, "%ld\n", uio_dummy_count);
}

static ssize_t store_count(struct device *dev, struct device_attribute *attr,
			   const char *buf, size_t count)
{
	uio_dummy_count = simple_strtol(buf, NULL, 10);
	return count;
}
static DEVICE_ATTR(count, S_IRUGO|S_IWUSR|S_IWGRP, show_count, store_count);

static ssize_t show_freq(struct device *dev, struct device_attribute *attr,
			 char *buf)
{
	return sprintf(buf, "%ld\n", freq);
}

static ssize_t store_freq(struct device *dev, struct device_attribute *attr,
			   const char *buf, size_t count)
{
	long tmp = simple_strtol(buf, NULL, 10);
	if (tmp < 1)
		tmp = 1;
	freq = tmp;
	return count;
}

static DEVICE_ATTR(freq, S_IRUGO|S_IWUSR|S_IWGRP, show_freq, store_freq);

static int uio_dummy_probe(struct platform_device *pdev)
{
	int ret;

	printk("uio_dummy_probe()\n" );
	freq = HZ;

	ret = device_create_file(&pdev->dev, &dev_attr_count);
	if (ret)
		goto error_register;
	ret = device_create_file(&pdev->dev, &dev_attr_freq);
	if (ret)
		goto error_file_count;

	return 0;

error_file_count:
	device_remove_file(&pdev->dev, &dev_attr_count);
error_register:
	return ret;
}

static int uio_dummy_remove(struct platform_device *pdev)
{
	printk("uio_dummy_remove()\n" );
	device_remove_file(&pdev->dev, &dev_attr_freq);
	device_remove_file(&pdev->dev, &dev_attr_count);
	return 0;
}

static struct platform_device *uio_dummy_device;

static struct platform_driver uio_dummy_driver = {
	.probe		= uio_dummy_probe,
	.remove		= uio_dummy_remove,
	.driver = {
		.name	= "uio_dummy",
	},
};

/*
 * Main initialization/remove routines
 */
static int __init uio_dummy_init(void)
{
	printk("uio_dummy_init( )\n" );
	uio_dummy_device = platform_device_register_simple("uio_dummy", -1,
							   NULL, 0);
	if (IS_ERR(uio_dummy_device))
		return PTR_ERR(uio_dummy_device);

	return platform_driver_register(&uio_dummy_driver);
}

static void __exit uio_dummy_exit(void)
{
	printk("uio_dummy_exit( )\n" );
	platform_device_unregister(uio_dummy_device);
	platform_driver_unregister(&uio_dummy_driver);
}

module_init(uio_dummy_init);
module_exit(uio_dummy_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("B R Sahu");
MODULE_DESCRIPTION("UIO dummy driver");

