/*
 * Linux device tree based driver example for Raspberry pi my_device
 *
 */
#include <linux/device.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/of_address.h>
#include <linux/of_irq.h>

static int my_probe(struct platform_device *op)
{
    struct resource *r = &op->resource[0];

    dev_notice(&op->dev, "probe() called\n");

    printk(KERN_INFO "name: %s\n", op->dev.of_node->name);
    printk(KERN_INFO "Resource Start: %08x\n", r->start);
    printk(KERN_INFO "Resource Size: %04x\n", resource_size(r));

    return 0;
}

static int my_remove(struct platform_device *pdev)
{
	/* Add per-device cleanup code here */

	dev_notice(&pdev->dev, "remove() called\n");

	return 0;
}

/* The of_device_id struct */
static struct of_device_id my_match_table[] = {
     {
             .compatible = "my_driver",
     },
     {}
};
MODULE_DEVICE_TABLE(of, my_match_table);

/* The driver struct itself */
static struct platform_driver my_platform_driver = {
        .probe = my_probe,
        .remove = my_remove,
        .driver = {
                .name = "my_driver",
                .owner = THIS_MODULE,
                .of_match_table = of_match_ptr(my_match_table),
        },
};


static int __init my_init(void)
{
	return platform_driver_register(&my_platform_driver);
}
module_init(my_init);

static void __exit my_exit(void)
{
	platform_driver_unregister(&my_platform_driver);
}
module_exit(my_exit);

/* Information about this module */
MODULE_DESCRIPTION("dtbd example");
MODULE_AUTHOR("Raspberry Pi");
MODULE_LICENSE("Dual BSD/GPL");
