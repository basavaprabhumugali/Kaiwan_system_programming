1. Create a Custom device tree for my_device in bcm2708_common.dtsi
   bcm2709-rpi-2-b.dts
   bcm2709.dtsi         
   bcm2708_common.dtsi
   skeleton.dtsi
        |
   bcm2709-rpi-2-b.dtb

2. Create a device tree based driver
