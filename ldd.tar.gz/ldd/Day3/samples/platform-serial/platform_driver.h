/*
 * Linux platform device example data structure
 *
*/
#ifndef __PLATFORM_DRIVER_H
#define __PLATFORM_DRIVER_H

struct platform_example_data {
	int value;
};

#endif /* __PLATFORM_DRIVER_H */
