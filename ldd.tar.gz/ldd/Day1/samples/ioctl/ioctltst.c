/***********************************************************************
*                                                                      *
* SourceName         : ioctltst.c                                      *
*                                                                      *
* Description        : This is an application program  to test the     *
*                      the driver ioctl.                               *
*                                                                      *
* Programmer         : ----------                                      *
* Date               : 15/07/2016                                      *
*                                                                      *
*----------------------------------------------------------------------*
* Notes                                                                *
* How To Build : On the command prompt, type                           *
*                "gcc -o ioctltst ioctltst.c" this will give the       *
*                output file 'ioctltst' which you can run.             *
*                                                                      *
* How To Load  : To run ioctltst, type command "./ioctltst"            *
*                                                                      *
***********************************************************************/

/*----------------------------------------------------------------------
 ************************** Include File *******************************
 *--------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>

/*--------------------------------------------------------------------*/
int err_sys(char *s);

char device[]  = {"/dev/mydevice"};
struct _MyData {
    long MyInt;
    char MyString[16];
    }MyData;

#define cmd0 _IOW(0xf0, 2, 4)

int main()
{
   int fd, nb;

   fd = open(device, 0666);
   if (fd <= 0)
   {
     err_sys("Can not open the device\n");
   }
   MyData.MyInt = 100;
   strcpy(MyData.MyString, "Welcome");
   ioctl(fd, cmd0, &MyData);
   close(fd);
   exit(0);
}

/* display err message and exit */

int err_sys(char *s)
{
  printf("%s\n", s);
  exit(1);
}

