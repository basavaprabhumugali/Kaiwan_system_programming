Setting up ADB/Fastboot in Linux

1.1 Setup the Android SDK for adb binaries or use the build terminal
      Create file etc/udev/rules.d/51-android.rules with following lines
      #for Fastboot bootloader interface
      SUBSYSTEM=="usb", ATTR{idVendor}=="18d1", MODE="0777", GROUP="adm"
      #for Device adb interface
      SUBSYSTEM=="usb", ATTR{idVendor}=="05c6", MODE="0777", GROUP="adm"

1.2 Reboot Linux machine and connect devices with micro USB cable

Make sure adb binary are in the path on your terminal


