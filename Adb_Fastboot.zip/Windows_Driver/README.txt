1.1 Setting up ADB in Windows

Download Android SDK Platform-Tools for Windows or use adb/fastboot from Adb_Fastboot.zip/AdbFastboot
https://developer.android.com/studio/releases/platform-tools.html

You only need to download Android SDK Platform-Tools and Google USB Driver, if you just want to play with the phone. If you plan to develop apps, install also the API of your choice and Eclipse Classic (this is the recommended version by Google devs).

To make available everywhere your platform tools (adb, fastboot, etc.), add your platform-tools directory to Path:
Connect USB cable to target.

Device will appear as Android and install the drivers from  folder Adb_Fastboot.zip/windows/usb_drive.

Please note:
Default there are 4 functional interfaces created only one is ADB other are used as diagnostic purpose (QPST, MDM, DIAG, MASS STORAGE).
Only one endpoint with following is applicable for ADB.
Your android_winusb.inf file should have below lines ADB.
android_winusb.inf
[Google.NTx86]
;Qualcomm SURF/FFA
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9025
%CompositeAdbInterface%     = USB_Install, USB\VID_05C6&PID_9025&MI_01
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9025
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9025&MI_01

;Qualcomm SURF/FFA (PTP+ADB)
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_904E
%CompositeAdbInterface%     = USB_Install, USB\VID_05C6&PID_904E&MI_01
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_904E
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_904E&MI_01

;Qualcomm SURF/FFA (MTP+ADB)
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9039
%CompositeAdbInterface%     = USB_Install, USB\VID_05C6&PID_9039&MI_01
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9039
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9039&MI_01

;Qualcomm SURF/FFA (UMS+ADB)
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9015
%CompositeAdbInterface%     = USB_Install, USB\VID_05C6&PID_9015&MI_00
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9015
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9015&MI_00
[Google.NTamd64]
;Qualcomm SURF/FFA
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9025
%CompositeAdbInterface%     = USB_Install, USB\VID_05C6&PID_9025&MI_01
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9025

%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9025&MI_01

;Qualcomm SURF/FFA (PTP+ADB)
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_904E
%CompositeAdbInterface%     = USB_Install, USB\VID_05C6&PID_904E&MI_01
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_904E
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_904E&MI_01

;Qualcomm SURF/FFA (MTP+ADB)
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9039
%CompositeAdbInterface%     = USB_Install, USB\VID_05C6&PID_9039&MI_01
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9039
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9039&MI_01

;Qualcomm SURF/FFA (UMS+ADB)
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9015
%CompositeAdbInterface%     = USB_Install, USB\VID_05C6&PID_9015&MI_00
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9015
%SingleAdbInterface%        = USB_Install, USB\VID_05C6&PID_9015&MI_00

[Strings]
SingleAdbInterface = "Android ADB Interface"
CompositeAdbInterface = "Android Composite ADB Interface"
SingleBootLoaderInterface = "Android Bootloader Interface"

When you see a Windows pop-up requesting drivers, provide the usb_driver folder path. Other device notifications from Windows should be ignored.

Each time you change your USB connection type from the Android Settings APP, you will see one time installation pop-up requesting for ADB driver to be installed,  provide the usb_driver folder.


